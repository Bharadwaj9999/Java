package com.capgemini.hbms.service;

import java.util.ArrayList;

import com.capgemini.hbms.bean.HBMSBookingBean;
import com.capgemini.hbms.bean.HBMSHotelBean;
import com.capgemini.hbms.bean.HBMSRoomBean;
import com.capgemini.hbms.bean.HBMSUserBean;
import com.capgemini.hbms.dao.HBMSDaoImpl;
import com.capgemini.hbms.dao.IHBMSDao;
import com.capgemini.hbms.exception.HBMSException;

public class HBMSServiceImpl implements IHBMSService{
	static IHBMSDao dao=new HBMSDaoImpl();
	@Override
	public boolean isValidLoginDetails(String username, String password) throws HBMSException {
		return dao.isValidLoginDetails(username,password);
	}
	@Override
	public boolean registerUser(HBMSUserBean userBean) throws HBMSException {
		
		return dao.registerUser(userBean);
	}
	@Override
	public ArrayList<HBMSHotelBean> getHotelList() throws HBMSException {
		return dao.getHotelList();
	}
	@Override
	public ArrayList<HBMSRoomBean> getRoomList(String id) throws HBMSException {
		return dao.getRoomList(id);
	}
	@Override
	public String getUserId(String username, String password) throws HBMSException {
		return dao.getUserId(username,password);
	}
	@Override
	public float getRoomAmount(String roomId) throws HBMSException {
		return dao.getRoomAmount(roomId);
	}
	@Override
	public String addBookingDetails(HBMSBookingBean booking) throws HBMSException {
		return dao.addBookingDetails(booking);
	}
	@Override
	public HBMSBookingBean getBookingDetails(String bookingId) throws HBMSException {
		return dao.getBookingDetails(bookingId);
	}
	@Override
	public String addHotelDetails(HBMSHotelBean bean) throws HBMSException {
		return dao.addHotelDetails(bean);
	}
	@Override
	public boolean isValidHotelId(String hotelID) throws HBMSException {
		return dao.isValidHotelId(hotelID);
	}
	@Override
	public ArrayList<HBMSBookingBean> getBookingsOfHotel(String hotelID) throws HBMSException {
		return dao.getBookingsOfHotel(hotelID);
	}
	@Override
	public void deleteHotel(String hotelID) throws HBMSException {
		dao.deleteHotel(hotelID);
		
	}
	@Override
	public boolean isValidRoomId(String roomID) throws HBMSException {
		return dao.isValidRoomId(roomID);
		
	}
	@Override
	public void deleteRoom(String roomID) throws HBMSException {
		dao.deleteRoom(roomID);
		
	}

}
