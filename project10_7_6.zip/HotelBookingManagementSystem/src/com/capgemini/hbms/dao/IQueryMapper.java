package com.capgemini.hbms.dao;

public interface IQueryMapper {
	String userValidateQuery = "select count(*) from users where user_name=? and password=?";
	String registerUserQuery = "insert into Users values(user_id_seq.nextval,?,?,?,?,?,?,?)";
	String getHotelListQuery = "select * from hotel";
	String getRoomListQuery = "select * from roomdetails where hotel_Id=?";
	String getUserIdQuery = "select user_id from users where user_name=? and password=?";
	String getRoomAmountQuery = "select per_night_rate from roomdetails where room_id=?";
	String addBookingDetailsQuery ="insert into bookingdetails values(booking_id_seq.nextval,?,?,?,?,?,?,?)";
	String getBookingId = "select booking_id_seq.currval from dual";
	String getBookingDetailsQuery = "select * from bookingdetails where booking_id=?";
	String hotelAddQuery = "insert into hotel values(hotel_id_seq.nextval,?,?,?,?,?,?,?,?,?,?,?)";
	String getHotelId = "select hotel_id_seq.currval from dual";
	String validHotelQuery = "select count(*) from hotel where hotel_id=?";
	String getBookingOfHotelQuery = "select * from bookingdetails b,roomdetails r where r.room_id=b.room_id and r.hotel_id=?";
	String deleteHotelQuery ="Delete from hotel where hotel_id=?";
	String validRoomQuery ="select count(*) from roomdetails where room_id=?";
	String deleteRoomQuery = "Delete from roomdetails where room_id=?";
	String getGuestListQuery = "select u.user_name,u.mobile_no,u.email,b.booking_id,r.room_id from users u,roomdetails r,bookingdetails b where r.room_id=b.room_id and u.user_id=b.user_id and r.hotel_id=?";
	String getBookingListQuery = "select * from bookingdetails where booked_from=?";
	String checkAvailabilityQuery ="update roomdetails set availability='available' where room_id IN (select room_id from bookingdetails where (booked_to-sysdate)<-1)";
	String changeStatusQuery = "update roomdetails set availability='not available' where room_id=?";
	String checkUserNameQuery = "select count(*) from users where user_name=?";
	String getBookedRoomCountQuery ="select count(*) from roomdetails where hotel_id=? and availability='not available'";
	String checkRoomStatus = "select count(*) from roomdetails where room_id=? and availability='not available'";
	String roomAddQuery = "insert into roomDetails values(?,room_id_seq.nextval,?,?,?,?,?)";
	String getRoomId = "select room_id_seq.currval from dual";
	String deleteBookingsOfRoomQuery ="delete from bookingdetails where room_id=?";
	String updateRoomTypeQuery = "update roomdetails set room_type=? where room_id=?";
	String updateRoomRentQuery = "update roomdetails set per_night_rate=? where room_id=?";
	String deleteBookingsOfHotelRoomQuery = "delete from bookingdetails where room_id IN (select room_id from roomdetails where hotel_id=?)";
	String deleteHotelRoomQuery ="delete from roomdetails where hotel_id=?";
	String modifyRatingQuery = "update hotel set rating=? where hotel_id=?";
	String modifyAvgRateQuery = "update hotel set avg_rate_per_night=? where hotel_id=?";
	String modifyDescriptionQuery ="update hotel set description=? where hotel_id=?";
	String getBookingsQuery = "select * from bookingdetails where user_id=?";
}