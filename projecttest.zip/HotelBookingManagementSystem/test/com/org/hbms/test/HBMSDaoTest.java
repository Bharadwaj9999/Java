package com.org.hbms.test;
import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.*;

import com.org.hbms.bean.HBMSBookingBean;
import com.org.hbms.bean.HBMSHotelBean;
import com.org.hbms.bean.HBMSRoomBean;
import com.org.hbms.bean.HBMSUserBean;
import com.org.hbms.dao.HBMSDaoImpl;
import com.org.hbms.dao.IHBMSDao;
import com.org.hbms.exception.HBMSException;
public class HBMSDaoTest {
	static IHBMSDao dao;
	static HBMSBookingBean bookingBean;
	static HBMSHotelBean hotelBean;
	static HBMSRoomBean roomBean;
	static HBMSUserBean userBean;
	
	@BeforeClass
	public static void initialize()
	{
		dao=new HBMSDaoImpl();
	}
	
	@Test
	public void testRegisterUser() throws HBMSException
	{
		userBean=new HBMSUserBean();
		userBean.setPassword("trini12");
		userBean.setUserName("trini12");
		userBean.setRole("user");
		userBean.setMobileNo("7659840158");
		userBean.setPhone("7659840158");
		userBean.setAddress("sipcot it park");
		userBean.setEmail("sai@gmail.com");
		assertEquals("1070", dao.registerUser(userBean));
	}
	
	@Test
	public void testValidUserLogin() throws HBMSException
	{
		String username="trini12";
		String password="trini12";
		assertEquals(true, dao.validateUserLogin(username, password));
	}
	
	@Test
	public void testInValidUserLogin() throws HBMSException
	{
		String username="trini123";
		String password="trini123";
		assertEquals(false, dao.validateUserLogin(username, password));
	}
	
	@Test
	public void testGetHotelDetails() throws HBMSException
	{
		assertNotNull(dao.getHotelDetails());
	}
	
	@Test
	public void testGetUserDetails() throws HBMSException
	{
		String username="trini12";
		String password="trini12";
		assertNotNull(dao.getUserDetails(username, password));
	}
	
	@Test
	public void testInvalidGetUserDetails() throws HBMSException
	{
		String username="trini123";
		String password="trini123";
		assertNull(dao.getUserDetails(username, password));
	}
	
	@Test
	public void testDisplayHotelRooms() throws HBMSException
	{
		assertNotNull(dao.displayRooms("4020"));
	}
	
	
}
