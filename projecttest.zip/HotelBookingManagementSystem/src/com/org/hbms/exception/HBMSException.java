package com.org.hbms.exception;

public class HBMSException extends Exception{
	private String msg;
	public HBMSException(String msg)
	{
		this.msg=msg;
	}
	public String toStirng()
	{
		return this.msg;
	}
}
