package com.org.hbms.pi;

import java.util.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import javax.sql.rowset.serial.SerialArray;

import com.org.hbms.bean.HBMSBookingBean;
import com.org.hbms.bean.HBMSHotelBean;
import com.org.hbms.bean.HBMSRoomBean;
import com.org.hbms.bean.HBMSUserBean;
import com.org.hbms.exception.HBMSException;
import com.org.hbms.service.HBMSserviceImpl;
import com.org.hbms.service.IHBMSservice;

public final class HBMSMain {
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) throws HBMSException, SQLException {
		String rUserName,rPassword,rUserId,rMobileNo,rPhone,rRole,rEmail,rAddress;
		
		HBMSUserBean b=new HBMSUserBean();
		IHBMSservice s1=new HBMSserviceImpl();
		s1.checkAvaialbilityStatus();
		System.out.println("       Welcome to Capgemini Group Of Hotels\n");
		int ch;
		String username,password;
		do
		{
			System.out.println("Enter your choice");
			System.out.println("1.User Login\t2.Admin Login\t3.User Registration\t4.Exit");
			ch=sc.nextInt();
			if(ch==1)
			{
				System.out.println("Please Enter Login Credentials");
				System.out.println("Enter User Name:");
				username=sc.next();
				System.out.println("Enter Password:");
				password=sc.next();
				if(s1.validateUserLogin(username,password))
				{
					System.out.println("Welcome "+username);
					HBMSUserBean user=s1.getUserDetails(username,password);
					displayHotels(user);			
				}
				else
				{
					System.out.println("Invalid Login Credentials");
				}
			}
			else if(ch==2)
			{
				System.out.println("Please Enter Login Credentials");
				System.out.println("Username:");
				username=sc.next();
				System.out.println("Password:");
				password=sc.next();
				if(s1.validateAdminLogin(username,password))
				{
					System.out.println("Welcome Admin");
					displayAdminMenu();
				}
				else
				{
					System.out.println("Invalid Login Credentials");
				}
			}
			else if(ch==3)
			{
				System.out.println("Fill out the following fields:");
				System.out.println("Enter User Name:");
				rUserName=sc.next();
				while(true)
				{
					if(s1.isValidUsername(rUserName))
					{
						break;
					}
					else
					{
						System.out.println("Enter Valid User Name");
						rUserName=sc.next();
					}
				}
				System.out.println("Enter Password:");
				rPassword=sc.next();
				while(true)
				{
					if(s1.isValidPassword(rPassword))
					{
						break;
					}
					else
					{
						System.out.println("Enter Valid Password");
						rPassword=sc.next();
					}
				}
				System.out.println("Enter Mobile Number:");
				rMobileNo=sc.next();
				while(true)
				{
					if(s1.isValidMobileNo(rMobileNo))
					{
						break;
					}
					else
					{
						System.out.println("Enter Valid Mobile No");
						//System.out.println("Enter Mobile Number:");
						rMobileNo=sc.next();
					}
				}
				System.out.println("Enter Phone number:");
				rPhone=sc.next();
				while(true)
				{
					if(s1.isValidPhoneNo(rPhone))
					{
						break;
					}
					else
					{
						System.out.println("Enter Valid Phone No");
						//System.out.println("Enter Phone number:");
						rPhone=sc.next();
					}
				}
				System.out.println("Enter your Address:");
				rAddress=sc.next();
				while(true)
				{
					if(s1.isValidAddress(rAddress))
					{
						break;
					}
					else
					{
						System.out.println("Enter Valid Address");
						//System.out.println("Enter your Address:");
						rAddress=sc.next();
					}
				}
				System.out.println("Enter your Mail Id:");
				rEmail=sc.next();
				while(true)
				{
					int mailLength=rEmail.length();
					if(mailLength<=30)
					{
					if(s1.isValidEmailId(rEmail))
					{
						break;
					}
					else
					{
						System.out.println("Enter Valid Email Id");
						//System.out.println("Enter your Mail Id:");
						rEmail=sc.next();
					}
					}
					else
					{
						System.out.println("Mail Id must be less than 25 characters");
						System.out.println("Enter Valid Email Id:");
						rEmail=sc.next();
					}
				}
				b.setPassword(rPassword);
				b.setUserName(rUserName);
				b.setMobileNo(rMobileNo);
				b.setPhone(rPhone);
				b.setRole("user");
				b.setAddress(rAddress);
				b.setEmail(rEmail);
				String userId=s1.registerUser(b);
				b.setUserId(userId);
				System.out.println("You have registered successfully with registration ID:"+b.getUserId());
			}
			else if(ch==4)
			{
				System.out.println("Thank you");
				break;
			}
			else
			{
				System.out.println("Please Enter Valid Choice");
			}
		}while(ch!=4);
	}

	private static void displayAdminMenu() {
		int op,choice;
		String hotelId,cityName,address,email,fax,phoneNo1,phoneNo2,avgRatePerNight,rating,description,hotelName,roomId,roomNo,roomType,availability;
		float perNightRent;
		IHBMSservice s1=new HBMSserviceImpl();
		HBMSHotelBean hotel=null;
		HBMSRoomBean room=null;
		do
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter your Choice:");
			System.out.println("1.Hotel Management\t2.Room Management\t3.Generate Report\t4.Exit");
			choice=sc.nextInt();
			if(choice==1)
			{
				do
				{
					System.out.println("Enter Operation to Perform");
					System.out.println("1.Add Hotel\t2.Delete Hotel\t3.Modify hotel\t4.Exit");
					op=sc.nextInt();
					if(op==1)
					{
						hotel=new HBMSHotelBean();
						System.out.println("Fill the following details");
						System.out.println("City Name");
						cityName=sc.next();
						while(true)
						{
							if(s1.isValidCity(cityName))
							{
								break;
							}
							else
							{
								System.out.println("Enter Valid City Name");
								//System.out.println("Enter City Name:");
								cityName=sc.next();
							}
						}
						System.out.println("Hotel name");
						hotelName=sc.next();
						while(true)
						{
							if(s1.isValidHotelName(hotelName))
							{
								break;
							}
							else
							{
								System.out.println("Enter Valid Hotel Name");
								//System.out.println("Enter Hotel Name:");
								hotelName=sc.next();
							}
						}
						System.out.println("Hotel Address");
						address=sc.next();
						while(true)
						{
							if(s1.isValidHotelAddress(address))
							{
								break;
							}
							else
							{
								System.out.println("Enter Valid Hotel Address");
								//System.out.println("Enter Hotel Address");
								address=sc.next();
							}
						}
						System.out.println("Hotel Description");
						description=sc.next();
						while(true)
						{
							if(s1.isValidHotelDescription(description))
							{
								break;
							}
							else
							{
								System.out.println("The description should be less than 50 characters");
								//System.out.println("Enter Description:");
								description=sc.next();
							}
						}
						System.out.println("Average rate per night");
						avgRatePerNight=sc.next();
						while(true)
						{
							if(s1.isValidAvgRate(avgRatePerNight))
							{
								break;
							}
							else
							{
								System.out.println("Enter Valid Average Rate Per Night");
								//System.out.println("Enter average rate per night: ");
								avgRatePerNight=sc.next();
							}
						}
						System.out.println("Phone Number - 1:");
						phoneNo1=sc.next();
						while(true)
						{
							if(s1.isValidPhoneNo1(phoneNo1))
							{
								break;
							}
							else
							{
								System.out.println("Enter Valid Phone Number");
								//System.out.println("Enter Phone Number:");
								phoneNo1=sc.next();
							}
						}
						System.out.println("Phone Number - 2");
						phoneNo2=sc.next();
						while(true)
						{
							if(s1.isValidPhoneNo2(phoneNo2))
							{
								break;
							}
							else
							{
								System.out.println("Enter Valid Phone Number:");
								phoneNo2=sc.next();
							}
						}

						System.out.println("rating");
						rating=sc.next();
						System.out.println("email");
						email=sc.next();
						while(true)
						{
							int mailLength=email.length();
							if(mailLength<=30)
							{
								if(s1.isValidEmail(email))
								{
									break;
								}
								else
								{
									System.out.println("Enter Valid Email Id:");
									email=sc.next();
								}
							}
							else
							{
								System.out.println("Mail Id must be less than 30 characters");
								System.out.println("Enter Valid Email Id:");
								email=sc.next();
							}
						}
						System.out.println("fax");
						fax=sc.next();
						hotel.setCity(cityName);
						hotel.setHotelName(hotelName);
						hotel.setAddress(address);
						hotel.setDescription(description);
						hotel.setAvgRatePerNight(avgRatePerNight);
						hotel.setPhoneNo1(phoneNo1);
						hotel.setPhoneNo2(phoneNo2);
						hotel.setRating(rating);
						hotel.setEmail(email);
						hotel.setFax(fax);
						try
						{
							hotelId=s1.addHotelDetails(hotel);
							hotel.setHotelId(hotelId);
							System.out.println("hotel added with hotelid:"+hotelId);
						} 
						catch (HBMSException e)
						{
							System.out.println(e.getMessage());
						}
					}
					else if(op==2)
					{
						System.out.println("Enter Hotel Id to delete:");
						hotelId=sc.next();
						try 
						{
							if(s1.isValidHotelId(hotelId))
							{
								s1.deleteHotelRooms(hotelId);
								s1.deleteHotel(hotelId);
							}
							else
							{
								System.out.println("Please Enter Valid HotelId");
							}
						}
						catch (HBMSException e) {
							System.out.println(e.getMessage());
						}
					}
					else if(op==3)
					{
						System.out.println("Enter Hotel Id to Modify:");
							hotelId=sc.next();
							try 
							{
								if(s1.isValidHotelId(hotelId))
								{
									
									do{
										System.out.println("Select field to modify:");
										System.out.println("1.Rating\t2.Average rate per night\t3.Description\t4.Exit");
										int ch=sc.nextInt();
										if(ch==1)
										{
											System.out.println("Enter new rating:");
											String newRating=sc.next();
											s1.modifyRating(hotelId,newRating);
											System.out.println("Hotel Rating is Modified Successfully.");
										}
										else if(ch==2)
										{
											System.out.println("Enter new Average Rate per Night:");
											float newAvgRate=sc.nextFloat();
											s1.modifyAvgRate(hotelId,newAvgRate);
											System.out.println("Hotel Average Rate Per Night is Modified Successfully.");
										}
										else if(ch==3)
										{
											Scanner s=new Scanner(System.in).useDelimiter("\n");
											
											System.out.println("Enter new Description:");
											String newDesc=s.next();
											s1.modifyDesc(hotelId,newDesc);
											System.out.println("Hotel Description is Modified Successfully.");
										}
										else if(ch==4)
										{
											break;
										}
										else
										{
											System.out.println("Invalid Choice.");
											System.out.println("Enter valid choice:");
											ch=sc.nextInt();
										}
										
									}while(true);
								}
								else
								{
									System.out.println("Please Enter Valid HotelId");
								}
							}
							catch (HBMSException e) {
								System.out.println(e.getMessage());
							}
					}
					else if(op==4)
					{
						break;
					}
					else
					{
						System.out.println("Please Enter Valid Choice:");
					}
				}while(op!=3);
			}
			else if(choice==2)
			{
				do
				{
					System.out.println("Enter Operation to perform");
					System.out.println("1.Add room\t2.Delete room\t3.Modify room\t4.Exit");
					op=sc.nextInt();
					if(op==1)
					{
						room=new HBMSRoomBean();
						System.out.println("Enter HotelId");
						hotelId=sc.next();
						try 
						{
							if(s1.isValidHotelId(hotelId))
							{
								room.setHotelId(hotelId);
								System.out.println("Enter Room Number");
								roomNo=sc.next();
								room.setRoomNo(roomNo);
								int ch;
								do
								{
									System.out.println("Select Room Type\n1.Standard non A/C room\t2.Standard A/C room\t3.Executive A/C room\t4.Deluxe A/C room ");
									ch=sc.nextInt();
									if(ch==1)
									{
										roomType="Standard non A/C room";
										break;
									}
									else if(ch==2)
									{
										roomType="Standard A/C room";
										break;
									}
									else if(ch==3)
									{
										roomType="Executive A/C room";
										break;
									}
									else if(ch==4)
									{
										roomType="Deluxe A/C room";
										break;
									}
									else
									{
										System.out.println("Please select valid option");
									}
								}while(true);
								room.setRoomType(roomType);
								System.out.println("Enter Room cost per night:");
								perNightRent=sc.nextFloat();
								room.setPerNightRate(perNightRent);
								do
								{
									System.out.println("Room availability\t1.True\t2.False");
									ch=sc.nextInt();
									if(ch==1)
									{
										availability="true";
										break;
									}
									else if(ch==2)
									{
										availability="false";
										break;
									}
									else
									{
										System.out.println("Please Select Valid Choice:");
									}
								}while(true);
								room.setAvailability(availability);
								roomId=s1.addRoomDetails(room);
								room.setRoomId(roomId);
								System.out.println("room details added sucessfully with roomId:"+roomId);
							}
							else
							{
								System.out.println("enter valid hotelid");
							}
						} 
						catch (HBMSException e)
						{
							System.out.println(e.getMessage());
						}
					}
					else if(op==2)
					{
						System.out.println("Enter Room Id to delete:");
						roomId=sc.next();
						try 
						{
							if(s1.isValidRoomId(roomId))
							{
								s1.deleteRoom(roomId);
							}
							else
							{
								System.out.println("Please Enter Valid RoomId");
							}
						}
						catch (HBMSException e) {
							System.out.println(e.getMessage());
						}
					}
					else if(op==3)
					{
						room=new HBMSRoomBean();
						try 
						{
								System.out.println("Enter Room Id:");
								roomId=sc.next();
								room.setRoomId(roomId);
								if(s1.isValidRoomId(roomId))
								{
									do{
										System.out.println("1.Modify Room Type\t2.Modify Rate Per Night\t3.exit");
										int option=sc.nextInt();
										roomType=null;
										if(option==1)
										{
											System.out.println("Select Room Type:\n1.Standard non A/C room\t2.Standard A/C room\t3.Executive A/C room\t4.Deluxe A/C room ");
											int ch=sc.nextInt();
											if(ch==1)
											{
												roomType="Standard non A/C room";	
											}
											else if(ch==2)
											{
												roomType="Standard A/C room";
												
											}
											else if(ch==3)
											{
												roomType="Executive A/C room";
												
											}
											else if(ch==4)
											{
												roomType="Deluxe A/C room";
												
											}
											s1.updateRoomType(roomType,roomId);
											System.out.println("Room Type is updated Successfully!!!");
										}
										else if(option==2)
										{
											System.out.println("Enter Per Night Rent:");
											perNightRent=sc.nextFloat();
											s1.updatePerNightRent(perNightRent,roomId);
											System.out.println("Room Rent is updated successfully!!!");
											
										}
										else if(option==3)
										{
											break;
										}
									}while(true);
								}
								else
								{
									System.out.println("Please Enter Valid RoomId");
								}
						}
						catch(HBMSException e)
						{
							System.out.println(e.getMessage());
						}
					}
					else if(op==4)
					{
						break;
					}
					else
					{
						System.out.println("Please Enter Valid Choice");
					}
				}while(op!=3);
			}
			else if(choice==3)
			{
				do
				{
					System.out.println("Select which report to generate");
					System.out.println("1.View List of Hotels\t2.View Bookings of specific hotel\t3.View guest list of specific hotel\t4.View bookings for specified date\t5.Exit");
					op=sc.nextInt();
					if(op==1)
					{
						System.out.println("List of Hotels :");
						StringBuilder hotelDetails;
						try 
						{
							hotelDetails = s1.getHotelDetails();
							System.out.println(hotelDetails);
						} 
						catch (HBMSException e)
						{
							System.out.println(e.getMessage());
						}
						
					}
					else if(op==2)
					{
						System.out.println("Enter HotelId-to get bookings:");
						hotelId=sc.next();
						StringBuilder hotelDetails;
						try
						{
							if(s1.isValidHotelId(hotelId))
							{
								hotelDetails=s1.getBookingOfHotel(hotelId);
								if(hotelDetails!=null)
								{
									System.out.println("Bookings of hotel "+hotelId+" are:");
									System.out.println(hotelDetails);
								}
							}
							else
							{
								System.out.println("invalid hotel Id");
							}
						} 
						catch (HBMSException e)
						{
							System.out.println(e.getMessage());
						}
					}
					else if(op==3)
					{
						System.out.println("Enter hotel Id-to view guest list:");
						hotelId=sc.next();
						StringBuilder guestList;
						try
						{
							if(s1.isValidHotelId(hotelId))
							{
								guestList=s1.getGuestList(hotelId);
								System.out.println("Guest available in the hotel:"+hotelId+" are:");
								System.out.println(guestList);
							}
							else
							{
								System.out.println("Invalid Hotel Id");
							}
						} 
						catch (HBMSException e)
						{
							System.out.println(e.getMessage());
						}
					}
					else if(op==4)
					{
						System.out.println("Enter date to view bookings of that date(format-dd/mm/yyyy):");
						String date=sc.next();
						try 
						{
							StringBuilder bookingOfDate=s1.getBookingOfSpecifiesDate(date);
							System.out.println(bookingOfDate);
						} 
						catch (HBMSException e)
						{
							
						}
						
					}
					else if(op==5)
					{
						break;
					}
					else
					{
						System.out.println("Please select valid choice:");
					}
				}while(op!=5);
			}
			else if(choice==4)
			{
				break;
			}
			else
			{
				System.out.println("Please enter valid choice:");
			}
		}while(choice!=3);
		
	}

	private static void displayHotels(HBMSUserBean user) {
		IHBMSservice s1=new HBMSserviceImpl();
		HBMSBookingBean booking=null;
		Scanner sc=new Scanner(System.in);
		String bookingId,date1,date2;
		int noOfAdults,noOfChildren,diff;
		float amount;
		String expectedPattern = "dd/MM/yyyy";
	    SimpleDateFormat formatter = new SimpleDateFormat(expectedPattern);
		if(user.getRole().equals("user"))
		{
			try
			{
			do
			{
				System.out.println("Enter your option\n1.book hotel room\t2.see booking details\t3.exit");
				int option=sc.nextInt();
				if(option==1)
				{
					System.out.println("Hotels and their descriptions : ");
					System.out.println("Select hotel from the below list:");
						StringBuilder hotelDetails=s1.getHotelDetails();
						System.out.println(hotelDetails);
						Date d=new Date();
						Date d1,d2;
						if(hotelDetails.length()>0)
						{
							System.out.println("Enter Hotel ID to view rooms:");
							String hotel_id=sc.next();
							while(true)
							{
								if(s1.isValidHotelId(hotel_id))
								{
									StringBuilder roomDetails=s1.displayRooms(hotel_id);
									System.out.println("Select room from the below list:");
									System.out.println(roomDetails);
									System.out.println("Enter Room ID to go to booking page:");
									String roomId=sc.next();
									if(s1.isValidRoomId(roomId))
									{
										booking=new HBMSBookingBean();
										booking.setUserId(user.getUserId());
										booking.setRoomId(roomId);
										while(true)
										{
											System.out.println("Enter booking from date(format-dd/mm/yyyy):");
											date1=sc.next();
											d1=formatter.parse(date1);
											diff=(int) ((d1.getTime()-d.getTime()) / (1000 * 60 * 60 * 24));
											if(diff<0)
											{
												System.out.println("from date couldn't be less than today");
											}
											else
											{
												break;
											}
										}
										booking.setBookedFrom(d1);
										while(true)
										{
											System.out.println("Enter booking to date(format-dd/mm/yyyy):");
											date2=sc.next();
											d2=formatter.parse(date2);
											diff=(int) ((d2.getTime()-d1.getTime()) / (1000 * 60 * 60 * 24));
											if(diff<0)
											{
												System.out.println("please enter valid to date");
											}
											else if(diff>10)
											{
												System.out.println("sorry you can book for a max period of 10 days");
											}
											else
											{
												break;
											}
										}
										booking.setBookedTo(d2);
										while(true)
										{
											while(true)
											{
												System.out.println("Enter number of adults");
												noOfAdults=sc.nextInt();
												if(noOfAdults<0)
												{
													System.out.println("enter valid number");
												}
												else if(noOfAdults>4)
												{
													System.out.println("a room can accomdate a max of 4 people");
												}
												else
												{
													break;
												}
											}
											
											while(true)
											{
												System.out.println("Enter number of children");
												noOfChildren=sc.nextInt();
												if(noOfChildren<0)
												{
													System.out.println("please enter valid number");
												}
												else if(noOfChildren>4)
												{
													System.out.println("a room can accomdate a max of 4 people");
												}
												else
												{
													break;
												}
											}
											if((noOfAdults+noOfChildren)>4)
											{
												System.out.println("a room can accomdate a max of 4 people!!!please book another room");
											}
											else
											{
												break;
											}
										}
										booking.setNoOfAdults(noOfAdults);
										booking.setNoOfChildren(noOfChildren);
										amount=s1.getRoomAmount(roomId);
										if(diff==0)
										{
											diff=1;
										}
										amount=amount*diff;
										amount=(Math.round(amount*100))/100;
										System.out.println(amount);
										booking.setAmount(amount);
										String bookingID=s1.addBookingDetails(booking);
										booking.setBookingId(bookingID);
										System.out.println("Your booking is successful-with booking id "+bookingID);
										s1.changeRoomStatus(roomId);
									}
									break;
								}
								else
								{
									System.out.println("enter valid hotelId");
									hotel_id=sc.next();
								}
							}
						}
					
				}
				else if(option==2)
				{
					System.out.println("enter booking ID:");
					String id=sc.next();
					HBMSBookingBean bean=s1.getBookingDetails(id);
					if(bean==null)
					{
						System.out.println("no details available!!!please check booking id");
					}
					else
					{
						System.out.println("booking details are:");
						System.out.println("BOOKING_ID ROOM_ID USER_ID BOOKED_FROM BOOKED_TO NO_OF_ADULTS NO_OF_CHILDREN     AMOUNT\n---------- ------- ------- ----------- --------- ------------ -------------- ----------");
						System.out.println(bean.getBookingId()+"   "+bean.getRoomId()+"   "+bean.getUserId()+"   "+bean.getBookedFrom()+"   "
								+bean.getBookedTo()+"   "+bean.getNoOfAdults()+"    "+bean.getNoOfChildren()+"   "+bean.getAmount());
					}
				}
				else if(option==3)
				{
					System.out.println("Thank you!!!please visit us again");
					break;
				}
				else
				{
					System.out.println("please enter valid option");
				}
			}while(true);
			}
			catch (HBMSException e)
			{
					System.out.println(e.getMessage());
			} 
			catch (ParseException e) 
			{
				System.out.println("Error while converting date");
			}
		}
		else
		{
			
		}
	}

}
