package com.org.hbms.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.org.hbms.dao.IQueryMapper;
import com.org.hbms.util.DBConnection;
import com.org.hbms.bean.HBMSBookingBean;
import com.org.hbms.bean.HBMSHotelBean;
import com.org.hbms.bean.HBMSRoomBean;
import com.org.hbms.bean.HBMSUserBean;
import com.org.hbms.exception.HBMSException;

public class HBMSDaoImpl implements IHBMSDao{

	@Override
	public String registerUser(HBMSUserBean b) throws HBMSException{
			Connection conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			try {
				s = conn.prepareStatement(IQueryMapper.userRegisterQuery);
				s.setString(1,b.getPassword());
				s.setString(2,b.getRole());
				s.setString(3,b.getUserName());
				s.setString(4,b.getMobileNo());
				s.setString(5,b.getPhone());
				s.setString(6,b.getAddress());
				s.setString(7,b.getEmail());
				int c=s.executeUpdate();
				s=conn.prepareStatement(IQueryMapper.getUserIdQuery);
				ResultSet rt=s.executeQuery();
				rt.next();
				String id=rt.getString(1);
				return id;
			} 
			catch (SQLException e)
			{
				throw new HBMSException("problem in connecting to database");
			}
	}

	@Override
	public boolean validateUserLogin(String username, String password) throws HBMSException{
		Connection conn=DBConnection.getInstance().getConnection();
		PreparedStatement s;
		try {
			s = conn.prepareStatement(IQueryMapper.userValidQuery);
			s.setString(1,username);
			s.setString(2,password);
			ResultSet r=s.executeQuery();
			if(r.next())
			{
				int count=r.getInt(1);
				if(count>0)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} catch (SQLException e) {
			throw new HBMSException("problem in connecting to database");
		}
		
	}

	@Override
	public StringBuilder getHotelDetails() throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.hotelDetailsQuery);
			ResultSet st=s.executeQuery();
			StringBuilder details=new StringBuilder("");
			details.append("HotelId    City      hotelName       address                 description                 avgratepernight          phoneno1             phoneno2           rating            email             fax\n");
			details.append("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
			while(st.next())
			{
				details.append(st.getString(1)+"  |  ");
				details.append(st.getString(2)+"  |  ");
				details.append(st.getString(3)+"  |  ");
				details.append(st.getString(4)+"  |  ");
				details.append(st.getString(5)+"  |  ");
				details.append(st.getInt(6)+"  |  ");
				details.append(st.getString(7)+"  |  ");
				details.append(st.getString(8)+"  |  ");
				details.append(st.getString(9)+"  |  ");
				details.append(st.getString(10)+"  |  ");
				details.append(st.getString(11)+"  |  ");
				details.append("\n");
			}
			return details;
		} 
		catch (SQLException e) {
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public HBMSUserBean getUserDetails(String username, String password) throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		HBMSUserBean user=null;
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.getRoleQuery);
			s.setString(1,username);
			s.setString(2,password);
			ResultSet rs=s.executeQuery();
			if(rs.next())
			{
				user=new HBMSUserBean();
				user.setUserId(rs.getString(1));
				user.setPassword(rs.getString(2));
				user.setRole(rs.getString(3));
				user.setUserName(rs.getString(4));
				user.setMobileNo(rs.getString(5));
				user.setPhone(rs.getString(6));
				user.setAddress(rs.getString(7));
				user.setEmail(rs.getString(8));
			}
			return user;
		} catch (SQLException e) {
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public StringBuilder displayRooms(String hotelId) throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.displayRoomQuery);
			s.setString(1,hotelId);
			ResultSet st=s.executeQuery();
			StringBuilder details=new StringBuilder("");
			while(st.next())
			{
				if(st.getString(6).equals("true"))
				{
					details.append(st.getString(1)+"  |  ");
					details.append(st.getString(2)+"  |  ");
					details.append(st.getString(3)+"  |  ");
					details.append(st.getString(4)+"  |  ");
					details.append(st.getFloat(5)+"  |  ");
					details.append("available"+"  |  ");
					details.append("\n");
				}
			}
			return details;
		}
		catch(SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public boolean isValidHotelId(String hotel_id) throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.validHotelQuery);
			s.setString(1,hotel_id);
			ResultSet st=s.executeQuery();
			if(st.next())
			{
				int count=st.getInt(1);
				if(count>0)
				{
					return true;
				}
			}
			return false;
		}
		catch(SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public String addHotelDetails(HBMSHotelBean hotel) throws HBMSException {
		Connection conn=null;
		try {
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s = conn.prepareStatement(IQueryMapper.hotelAddQuery);
			s.setString(1,hotel.getCity());
			s.setString(2,hotel.getHotelName());
			s.setString(3,hotel.getAddress());
			s.setString(4,hotel.getDescription());
			s.setString(5,hotel.getAvgRatePerNight());
			s.setString(6,hotel.getPhoneNo1());
			s.setString(7,hotel.getPhoneNo2());
			s.setString(8,hotel.getRating());
			s.setString(9,hotel.getEmail());
			s.setString(10,hotel.getFax());
			InputStream fin = new FileInputStream("C:\\Users\\shsaranu\\Documents\\My Received Files\\management\\sea.jpg");
			s.setBinaryStream(11, fin);
			int c=s.executeUpdate();
			s=conn.prepareStatement(IQueryMapper.getHotelId);
			ResultSet rt=s.executeQuery();
			rt.next();
			String hotelId=rt.getString(1);
			return hotelId;
		} 
		catch (SQLException | FileNotFoundException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
		
	}

	@Override
	public void deleteHotel(String hotelId) throws HBMSException {
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.deleteHotelQuery);
			s.setString(1, hotelId);
			s.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
				
	}

	@Override
	public void deleteHotelRooms(String hotelId) throws HBMSException {
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.deleteHotelRoomQuery);
			s.setString(1, hotelId);
			s.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
		
	}

	@Override
	public String addRoomDetails(HBMSRoomBean room) throws HBMSException {
		try
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.addRoomDetailsQuery);
			try
			{
				s.setString(1, room.getHotelId());
				s.setString(2,room.getRoomNo());
				s.setString(3, room.getRoomType());
				s.setFloat(4,room.getPerNightRate());
				s.setString(5,room.getAvailability());
				s.executeUpdate();
			}
			catch(SQLException e)
			{
				System.out.println(e.getMessage());
			}
			s=conn.prepareStatement(IQueryMapper.getRoomIdQuery);
			ResultSet rt=s.executeQuery();
			rt.next();
			return rt.getString(1);
		}
		catch(SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public boolean isValidRoomId(String roomId) throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.validRoomQuery);
			s.setString(1,roomId);
			ResultSet st=s.executeQuery();
			if(st.next())
			{
				int count=st.getInt(1);
				if(count>0)
				{
					return true;
				}
			}
			return false;
		}
		catch(SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public void deleteRoom(String roomId) throws HBMSException {
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.deleteRoomQuery);
			s.setString(1, roomId);
			s.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public float getRoomAmount(String roomId) throws HBMSException {
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getRoomAmountQuery);
			s.setString(1, roomId);
			ResultSet re=s.executeQuery();
			re.next();
			return re.getFloat(1);
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public String addBookingDetails(HBMSBookingBean booking) throws HBMSException {
		String bookingID=null;
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.addBookingDetailsQuery);
			try
			{
			s.setString(1, booking.getRoomId());
			s.setString(2, booking.getUserId());
			s.setDate(3, new Date(booking.getBookedFrom().getTime()));
			s.setDate(4,new Date(booking.getBookedTo().getTime()));
			s.setInt(5, booking.getNoOfAdults());
			s.setInt(6,booking.getNoOfChildren());
			s.setFloat(7,booking.getAmount());
			s.executeUpdate();
			s=conn.prepareStatement(IQueryMapper.getBookingId);
			ResultSet rt=s.executeQuery();
			rt.next();
			bookingID=rt.getString(1);
			}
			catch(SQLException e)
			{
				System.out.println(e.getMessage());
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
		return bookingID;
	}

	@Override
	public StringBuilder getBookingOfHotel(String hotelId) throws HBMSException {
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getBookingOfHotelQuery);
			s.setString(1, hotelId);
			ResultSet st=s.executeQuery();
			StringBuilder details=new StringBuilder("");
			while(st.next())
			{
				details.append(st.getString(1)+"  |  ");
				details.append(st.getString(2)+"  |  ");
				details.append(st.getString(3)+"  |  ");
				details.append(st.getDate(4)+"  |  ");
				details.append(st.getDate(5)+"  |  ");
				details.append(st.getInt(6)+"  |  ");
				details.append(st.getInt(7)+"  |  ");
				details.append(st.getFloat(8)+" |  ");
				details.append("\n");
			}
			return details;
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public StringBuilder getGuestList(String hotelId) throws HBMSException {
		StringBuilder str=new StringBuilder("");
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getGuestListQuery);
			s.setString(1, hotelId);
			ResultSet rt=s.executeQuery();
			while(rt.next())
			{
				str.append(rt.getString(1)+"  |  ");
				str.append(rt.getString(2)+"  |  ");
				str.append(rt.getString(3)+"  |  ");
				str.append("\n");
			}
			return str;
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
		
	}

	@Override
	public void changeRoomStatus(String roomId) throws HBMSException {
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.changeStatusQuery);
			s.setString(1,roomId);
			s.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public StringBuilder getBookingOfSpecifiesDate(String date) throws HBMSException {
		StringBuilder str=new StringBuilder("");
		String expectedPattern = "dd/MM/yyyy";
		java.util.Date date1;
	    SimpleDateFormat formatter = new SimpleDateFormat(expectedPattern);
	    try 
	    {
			date1=formatter.parse(date);
		}
	    catch (ParseException e1) 
	    {
			throw new HBMSException("please enter valid date");
		}
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getBookingListQuery);
			s.setDate(1, new Date(date1.getTime()));
			ResultSet st=s.executeQuery();
			while(st.next())
			{
				str.append(st.getString(1)+"  |   ");
				str.append(st.getString(2)+"  |   ");
				str.append(st.getString(3)+"  |   ");
				str.append(st.getDate(4)+"  |   ");
				str.append(st.getDate(5)+"  |   ");
				str.append(st.getInt(6)+"  |   ");
				str.append(st.getInt(7)+"  |   ");
				str.append(st.getFloat(8)+"  |   ");
				str.append("\n");
			}
			
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
		return str;
	}

	@Override
	public void checkAvailabilityStatus() throws HBMSException {
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s=conn.prepareStatement(IQueryMapper.checkAvailabilityQuery);
			s.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public void updateRoomType(String roomType, String roomId) throws HBMSException {
		Connection conn=null;
		try {
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s=conn.prepareStatement(IQueryMapper.updateRoomType);
			s.setString(1,roomType);
			s.setString(2,roomId);
			s.executeUpdate();
		} catch (HBMSException | SQLException e) {
			
			throw new HBMSException("problem in connecting to database");	
		}
	}

	@Override
	public void updatePerNightRent(float perNightRent, String roomId) throws HBMSException {
		Connection conn=null;
		try 
		{
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s=conn.prepareStatement(IQueryMapper.updatePerNightRent);
			s.setFloat(1,perNightRent);
			s.setString(2, roomId);
			s.executeUpdate();
		} 
		catch (SQLException e) 
		{
			throw new HBMSException("problem in connecting to database");	
		}
	}

	@Override
	public HBMSBookingBean getBookingDetails(String id) throws HBMSException {
		Connection conn=null;
		HBMSBookingBean bean=new HBMSBookingBean();
		try 
		{
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getBookingDetailsQuery);
			s.setString(1, id);
			ResultSet st=s.executeQuery();
			if(st.next())
			{
				bean.setBookingId(st.getString(1));
				bean.setRoomId(st.getString(2));
				bean.setUserId(st.getString(3));
				bean.setBookedFrom(st.getDate(4));
				bean.setBookedTo(st.getDate(5));
				bean.setNoOfAdults(st.getInt(6));
				bean.setNoOfChildren(st.getInt(7));
				bean.setAmount(st.getFloat(8));
				return bean;
			}			
		} 
		catch (SQLException e) 
		{
			throw new HBMSException("problem in connecting to database");	
		}
		return null;
	}

	@Override
	public void modifyRating(String hotelId, String newRating) throws HBMSException {
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s=conn.prepareStatement(IQueryMapper.modifyRatingQuery);
			s.setInt(1,Integer.parseInt(newRating));
			s.setString(2,hotelId);
			s.executeUpdate();
		}
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public void modifyAvgRate(String hotelId, float newAvgRate) throws HBMSException{
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s=conn.prepareStatement(IQueryMapper.modifyAvgRateQuery);
			s.setFloat(1,newAvgRate);
			s.setString(2,hotelId);
			s.executeUpdate();
		}
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public void modifyDesc(String hotelId, String newDesc) throws HBMSException {
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s=conn.prepareStatement(IQueryMapper.modifyDescQuery);
			s.setString(1,newDesc);
			s.setString(2,hotelId);
			s.executeUpdate();
		}
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

}
