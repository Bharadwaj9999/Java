package com.capgemini.hbms.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.jms.Session;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.hbms.bean.HBMSBookingBean;
import com.capgemini.hbms.bean.HBMSHotelBean;
import com.capgemini.hbms.bean.HBMSRoomBean;
import com.capgemini.hbms.bean.HBMSUserBean;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.HBMSServiceImpl;
import com.capgemini.hbms.service.IHBMSService;

/**
 * Servlet implementation class HBMSController
 */
@WebServlet("/HBMSController")
public class HBMSController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HBMSController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation=request.getParameter("action");
		PrintWriter write=response.getWriter();
		IHBMSService service=new HBMSServiceImpl();
		try
		{
			if(operation.equals("login"))
			{
				String username=request.getParameter("username");
				String password=request.getParameter("password");
				if(username.equals("admin") && username.equals("admin"))
				{
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain.jsp");
					rd.include(request, response);
				}
				else if(service.isValidLoginDetails(username,password))
				{
					String userid=service.getUserId(username,password);
					HttpSession session=request.getSession();
					session.setAttribute("userid", userid);
					RequestDispatcher rd=request.getRequestDispatcher("/UserMain.jsp");
					rd.include(request, response);
				}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
					rd.include(request, response);
					write.print("<font color=red>invalid login details</font>");
				}
			}
			else if(operation.equals("SeeHotels"))
			{
				ArrayList<HBMSHotelBean> hotelList=service.getHotelList();
				request.setAttribute("hotellist", hotelList);
				RequestDispatcher rd=request.getRequestDispatcher("/HotelUser.jsp");
				rd.forward(request, response);
			}
			else if(operation.equals("SeebookingStatus"))
			{
				RequestDispatcher rd=request.getRequestDispatcher("/SearchStatus.jsp");
				rd.include(request, response);
			}
			else if(operation.equals("bookingdetails"))
			{
				String bookingId=request.getParameter("bookingid");
				HBMSBookingBean booking=service.getBookingDetails(bookingId);
				if(booking==null)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/SearchStatus.jsp");
					rd.include(request, response);
					write.print("please enter valid booking id");
				}
				else
				{
					request.setAttribute("booking", booking);
					RequestDispatcher rd=request.getRequestDispatcher("/BookingInfo.jsp");
					rd.include(request, response);
				}
			}
			else if(operation.equals("register"))
			{
				HBMSUserBean userBean=new HBMSUserBean();
				userBean.setPassword(request.getParameter("password"));
				userBean.setUserName(request.getParameter("username"));
				userBean.setMobileNo(request.getParameter("mobilenum"));
				userBean.setPhone(request.getParameter("phonenum"));
				userBean.setAddress(request.getParameter("address"));
				userBean.setEmail(request.getParameter("email"));
				userBean.setRole("user");
				if(service.registerUser(userBean))
				{
					RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
					rd.include(request, response);
					write.print("<font color=blue>registered sucesfully,login to continue</font>");
				}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("/Register.jsp");
					rd.include(request, response);
					write.print("<font color=red>registration unsucessful,please register again</font>");
				}
			}
			else if(operation.equals("roomDetails"))
			{
				String id=request.getParameter("roomid");
				HttpSession session=request.getSession(false);
				if(session!=null)
				{
					session.setAttribute("roomid", id);
					RequestDispatcher rd=request.getRequestDispatcher("/BookingUser.jsp");
					rd.include(request, response);
				}
			}
			else if(operation.equals("displayRooms"))
			{
				String id=request.getParameter("hotelid");
				ArrayList<HBMSRoomBean> roomList=service.getRoomList(id);
				request.setAttribute("roomlist", roomList);
				RequestDispatcher rd=request.getRequestDispatcher("/RoomUser.jsp");
				rd.include(request, response);
			}
			else if(operation.equals("addbooking"))
			{
				HBMSBookingBean booking=new HBMSBookingBean();
				HttpSession session=request.getSession(false);
				if(session!=null)
				{
					String d1=request.getParameter("bookedfromdate");
					String d2=request.getParameter("bookedtodate");
					String expectedPattern = "yyyy-MM-dd";
					SimpleDateFormat formatter = new SimpleDateFormat(expectedPattern);
					Date bookedfrom=formatter.parse(d1);
					Date bookedto=formatter.parse(d2);
					int diff=(int) ((bookedto.getTime()-bookedfrom.getTime()) / (1000 * 60 * 60 * 24));
					int noofadults=Integer.parseInt(request.getParameter("noofadults"));
					int noofchildren=Integer.parseInt(request.getParameter("noofchildren"));
					String roomid=(String) session.getAttribute("roomid");
					float amount=service.getRoomAmount(roomid);
					if(diff>0)
					{
						amount=amount*diff;
					}
					String userid=(String)session.getAttribute("userid");
					booking.setUserId(userid);
					booking.setRoomId(roomid);
					booking.setBokkedFrom(bookedfrom);
					booking.setBookedTo(bookedto);
					booking.setNoOfAdults(noofadults);
					booking.setNoOfChildren(noofchildren);
					booking.setAmount(amount);
					String bookingId=service.addBookingDetails(booking);
					booking.setBookingId(bookingId);
					request.setAttribute("booking", booking);
					RequestDispatcher rd=request.getRequestDispatcher("/BookingInfo.jsp");
					rd.include(request, response);
				}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
					rd.include(request, response);
				}
			}
			else if(operation.equals("logout"))
			{
				HttpSession session=request.getSession(false);
				session.invalidate();
				RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
				rd.include(request, response);
				write.print("logged out sucessfully");
			}
			else if(operation.equals("AddHotel"))
			{
				HBMSHotelBean bean=new HBMSHotelBean();
				bean.setCity(request.getParameter("city"));
				bean.setHotelName(request.getParameter("hotelName"));
				bean.setAddress(request.getParameter("address"));
				bean.setDescription(request.getParameter("description"));
				bean.setAvgRatePerNight(request.getParameter("avgRentPerNight"));
				bean.setPhoneNo1(request.getParameter("phoneNo1"));
				bean.setPhoneNo2(request.getParameter("phoneNo2"));
				bean.setRating(request.getParameter("rating"));
				bean.setEmail(request.getParameter("email"));
				bean.setFax(request.getParameter("fax"));
				InputStream fin = new FileInputStream(request.getParameter("image"));
				bean.setHotelImage(fin);
				String hotelId=service.addHotelDetails(bean);
				write.print("hotel added sucessfully with id:"+hotelId);
			}
		}
		catch(HBMSException | ParseException e)
		{
			write.print(e.getMessage());
		}
	}

}
