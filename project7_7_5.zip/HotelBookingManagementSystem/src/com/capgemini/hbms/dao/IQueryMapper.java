package com.capgemini.hbms.dao;

public interface IQueryMapper {
	String userValidateQuery = "select count(*) from users where user_name=? and password=?";
	String registerUserQuery = "insert into Users values(user_id_seq.nextval,?,?,?,?,?,?,?)";
	String getHotelListQuery = "select * from hotel";
	String getRoomListQuery = "select * from roomdetails where hotel_Id=?";
	String getUserIdQuery = "select user_id from users where user_name=? and password=?";
	String getRoomAmountQuery = "select per_night_rate from roomdetails where room_id=?";
	String addBookingDetailsQuery ="insert into bookingdetails values(booking_id_seq.nextval,?,?,?,?,?,?,?)";
	String getBookingId = "select booking_id_seq.currval from dual";
	String getBookingDetailsQuery = "select * from bookingdetails where booking_id=?";
	String hotelAddQuery = "insert into hotel values(hotel_id_seq.nextval,?,?,?,?,?,?,?,?,?,?,?)";
	String getHotelId = "select hotel_id_seq.currval from dual";
	String validHotelQuery = "select count(*) from hotel where hotel_id=?";
	String getBookingOfHotelQuery = "select * from bookingdetails b,roomdetails r where r.room_id=b.room_id and r.hotel_id=?";
	String deleteHotelQuery ="Delete from hotel where hotel_id=?";
	String validRoomQuery ="select count(*) from roomdetails where room_id=?";
	String deleteRoomQuery = "Delete from roomdetails where room_id=?";
	String getGuestListQuery = "select u.user_name,u.mobile_no,u.email,b.booking_id,r.room_id from users u,roomdetails r,bookingdetails b where r.room_id=b.room_id and u.user_id=b.user_id and r.hotel_id=?";
	String getBookingListQuery = "select * from bookingdetails where booked_from=?";
}